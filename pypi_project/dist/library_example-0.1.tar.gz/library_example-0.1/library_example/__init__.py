def lib_example_call():
    return "this was called from the example library"
