from setuptools import setup

setup(
    name='library_example',
    packages=['library_example'],
    description='Some Project to be shared',
    version='0.1',
    url='http://github.com/itc/library_example',
    author='Dev',
    author_email='docs@something.com',
    keywords=['pip','library','example']
    )
